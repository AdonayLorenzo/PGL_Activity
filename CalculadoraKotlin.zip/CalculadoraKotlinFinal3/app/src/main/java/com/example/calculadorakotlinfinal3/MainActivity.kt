package com.example.calculadorakotlinfinal3

import android.content.Context
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.calculadorakotlinfinal3.ui.theme.ComposeCalculatorTheme
import kotlin.text.isNotEmpty
import kotlin.text.toDouble

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ComposeCalculatorTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CalculatorScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen() {
    var number1 by remember { mutableStateOf("") }
    var number2 by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = number1,
            onValueChange = {
                if (it.all { char -> char.isDigit() || char == '.' }) {
                    number1 = it
                }
            },
            label = { Text("Ingrese el primer número") },
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged {
                    if (it.isFocused) {
                        showKeyboard(context)
                    }
                },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = number2,
            onValueChange = {
                if (it.all { char -> char.isDigit() || char == '.' }) {
                    number2 = it
                }
            },
            label = { Text("Ingrese el segundo número") },
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged {
                    if (it.isFocused) {
                        showKeyboard(context)
                    }
                },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            if (number1.isNotEmpty() && number2.isNotEmpty()) {
                try {
                    val num1 = number1.toDouble()
                    val num2 = number2.toDouble()
                    val sum = num1 + num2
                    result = sum.toString()
                } catch (e: NumberFormatException) {
                    result = "Error: Números inválidos"
                }
            } else {
                result = "Error: Ingrese ambos números"
            }
        }) {
            Text("Calcular Suma")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Resultado: $result")
    }
}

private fun showKeyboard(context: Context) {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
}

@Preview(showBackground = true)
@Composable
fun CalculatorScreenPreview() {
    ComposeCalculatorTheme {
        CalculatorScreen()
    }
}
