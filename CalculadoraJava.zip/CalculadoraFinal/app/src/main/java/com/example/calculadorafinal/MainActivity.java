package com.example.calculadorafinal;

import static android.widget.Toast.*;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber1, etNumber2;
    private TextView tvResult;
    private Button btnCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Referencias a los componentes de la interfaz
        etNumber1 = findViewById(R.id.etNumber1);
        etNumber2 = findViewById(R.id.etNumber2);
        tvResult = findViewById(R.id.tvResult);
        btnCalculate = findViewById(R.id.btnCalculate);

        // Solicitar el foco en etNumber1 al iniciar
        etNumber1.requestFocus();

        // Configuración del botón
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateSum();
            }
        });

        // OnFocusChangeListener para etNumber1
        etNumber1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    showKeyboard(etNumber1);
                }
            }
        });

        // OnFocusChangeListener para etNumber2
        etNumber2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    showKeyboard(etNumber2);
                }
            }
        });
    }

    private void calculateSum() {
        // Obtener los valores ingresados
        String num1Str = etNumber1.getText().toString();
        String num2Str = etNumber2.getText().toString();

        // Validar que los campos no estén vacíos
        if (TextUtils.isEmpty(num1Str) || TextUtils.isEmpty(num2Str)) {
            makeText(this, "Por favor, ingrese ambos números.", LENGTH_SHORT).show();
            return;
        }

        try {
            // Convertir a números
            double num1 = Double.parseDouble(num1Str);
            double num2 = Double.parseDouble(num2Str);

            // Calcular la suma
            double sum = num1 + num2;

            // Mostrar el resultado
            tvResult.setText("Resultado: " + sum);
        } catch (NumberFormatException e) {
            // Manejar errores de conversión
            makeText(this, "Por favor, ingrese números válidos.", LENGTH_SHORT).show();
        }
    }

    // Método para mostrar el teclado
    public void showKeyboard(EditText editText) {
        editText.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
    }
}